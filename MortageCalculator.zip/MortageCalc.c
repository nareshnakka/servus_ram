MortageCalc()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_reg_find("Search=Body",
		"SaveCount=HomePage_cnt",
		"Text=a class=\"\" title=\"Calculators\" href=\"/calculators\" target=\"\">",
		LAST);
	
	lr_start_transaction("01_HomePage");


	web_url("www.servus.ca", 
		"URL=https://www.servus.ca/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{HomePage_cnt}"))>0){
		lr_end_transaction("01_HomePage", LR_AUTO);
	}else{
		lr_end_transaction("01_HomePage", LR_FAIL);
	}

	lr_think_time(4);
	
	

	
	/* Calculators */

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_reg_find("Search=Body",
		"SaveCount=calc_pageCnt",
		"Text=href=\"/calculators/mortgage-calculator\"",
		LAST);
	
	lr_start_transaction("02_CalculatorsPage");


	web_url("Calculators", 
		"URL=https://www.servus.ca/calculators", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.servus.ca/life", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{calc_pageCnt}"))>0){
		lr_end_transaction("02_CalculatorsPage", LR_AUTO);
	}else{
		lr_end_transaction("02_CalculatorsPage", LR_FAIL);
	}

	lr_think_time(4);


	
	/* Mortage Calculator */

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_reg_find("Search=Body",
		"SaveCount=mc_pgCnt",
		"Text=Our mortgage calculator works as",
		LAST);
	
	lr_start_transaction("03_MortageCalculatorPage");


	web_url("Mortgage calculator", 
		"URL=https://www.servus.ca/calculators/mortgage-calculator", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.servus.ca/calculators", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_save_timestamp_param("tStamp",LAST);

	web_url("MortgageCalculator.html", 
		"URL=https://www.servus.ca/_layouts/ServusInternet/MortgageCalculator/MortgageCalculator.html?_={tStamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.servus.ca/calculators/mortgage-calculator", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{calc_pageCnt}"))>0){
		lr_end_transaction("03_MortageCalculatorPage", LR_AUTO);
	}else{
		lr_end_transaction("03_MortageCalculatorPage", LR_FAIL);
	}

	lr_think_time(4);

	/* I want to Calculate My Payment */
	
	
	web_save_timestamp_param("tStamp",LAST);

	web_reg_find("Search=Body",
		"SaveCount=caclmrtg_cnt",
		"Text=Choose mortgage options that fit your lifestyle",
		LAST);
	
	lr_start_transaction("04_MortageCalculationPage");	

	web_url("MortgageCalculator.html_2", 
		"URL=https://www.servus.ca/_layouts/ServusInternet/MortgageCalculator/MortgageCalculator.html?_={tStamp}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.servus.ca/calculators/mortgage-calculator", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{calc_pageCnt}"))>0){
		lr_end_transaction("04_MortageCalculationPage", LR_AUTO);
	}else{
		lr_end_transaction("04_MortageCalculationPage", LR_FAIL);
	}

	lr_think_time(4);

	/* Select Data */

	/* Calculate */
	
	/*
	
	No http requests are being made to Server while calculating the interest, because calculation is happening on the browser.	
	
	*/

	return 0;
}